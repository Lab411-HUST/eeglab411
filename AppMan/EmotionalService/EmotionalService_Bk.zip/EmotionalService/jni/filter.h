#ifndef _FILTER_H_
#define _FILTER_H_
	void filter(int size,double W1,double W2,double b);
	double besselI0(double x);
	double wn_kaiser(int n);
	double hd(int n);
	double hn(int n);
	double *getHn(int HnSize);
	double *getarrHn(int HnSize);
	double *setFilter(int *arrXn,int XnSize);
	int *getXnAdd(int *arrXn,int XnSize);
	double *BandPassFilter(int *arrXn,int XnSize,int hnSize,double W1,double W2,double b);
#endif
