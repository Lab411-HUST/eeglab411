/** Automatically generated file. DO NOT MODIFY */
package lab411.eeg.emotionalservice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}